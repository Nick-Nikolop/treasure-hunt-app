# Pages — screen-by-screen anatomy

Paths in `code` are relative to this kit. Screenshots are 1440 px wide unless they are in `02-screenshots/mobile/`.

---

## Global chrome (every page)

- **Header** — `03-source-code/components/pythea/site-header.tsx`. Left: small gold compass logo + "ΠΥΘΕΑΣ / Ο ΜΕΣΣΗΝΙΟΣ" stacked wordmark. Centre: tracked-caps nav — Η ΙΣΤΟΡΙΑ · ΤΟ ΗΜΕΡΟΛΟΓΙΟ · Ο ΘΗΣΑΥΡΟΣ · ΠΩΣ ΠΑΙΖΕΤΑΙ. Right: settings cog, ΣΥΝΔΕΣΗ (sign in), and a brass-outlined ΔΗΛΩΣΕ ΣΥΜΜΕΤΟΧΗ (register) button. On the journal it also shows a progress chip: "ΣΗΜΑΔΙ #3 · Γαλλία · 3/10".
- **Atmosphere** — `components/pythea/atmosphere.tsx` + `particles.tsx`. A fixed, barely visible layer of drifting dust motes and a warm vignette over the ink background.
- **Footer** — `components/pythea/site-footer.tsx`. Title "Το Ταξίδι του Πυθέα του Μεσσήνιου", the line "ΚΥΝΗΓΙ ΘΗΣΑΥΡΟΥ · ΚΑΛΑΜΑΤΑ · ΚΑΛΟΚΑΙΡΙ 2026", the brass italic tagline "ΑΝΑΚΑΛΥΨΕ ΤΟ ΑΓΝΩΣΤΟ ΜΕΣΑ ΣΤΟ ΓΝΩΡΙΜΟ", three link columns, coordinates "36°57′ · 22°06′" (Kalamata), and a huge ghosted "ΠΥΘΕΑΣ" wordmark bleeding off the bottom.

---

## 1. Journal — "Ημερολόγιο ταξιδιού" (the signature screen)

**Code:** `03-source-code/app/journal/page.tsx` → `components/pythea/poreia-view.tsx` (the book, pages and flip), `journal-cover.tsx`, `journal-widgets.tsx`.
**Screenshots:** `02-screenshots/journal/` (in reading order) and `02-screenshots/mobile/journal-mobile-*.jpg`.
**Content:** `04-content/journal-entries.md`.

Above the book: a brass feather icon + "ΗΜΕΡΟΛΟΓΙΟ ΤΑΞΙΔΙΟΥ" with a hairline rule and a "3 / 10" counter, an italic intro line ("Κάθε σελίδα κρατά ένα σημάδι από τα ταξίδια του Πυθέα…"), and two outlined buttons: ΠΩΣ ΠΑΙΖΕΤΑΙ and ΣΗΜΑΝΤΙΚΗ ΑΝΑΚΟΙΝΩΣΗ.

The book is a single spiral-bound notebook page (about 670 × 710 px on desktop) sitting on the dark desk with a deep drop shadow and a few page edges stacked beneath it. Below it: ΠΡΟΗΓΟΥΜΕΝΗ / ΕΠΟΜΕΝΗ buttons, page dots (the active one stretches into a brass pill), the hint "Πάτα ή σύρε για να γυρίσεις σελίδα", and a "light mode" toggle. Below that, an "ΟΙ ΑΛΛΟΙ ΕΞΕΡΕΥΝΗΤΕΣ" widget showing how many teams are on the same riddle.

### Page types, in order

| # | Screenshot | What it is |
| --- | --- | --- |
| Cover | `00-cover.jpg` | Dark leather cover with a brass double-rule frame and corner brackets, a red ribbon bookmark hanging from the top right, a red wax seal with a tiny compass in the centre, "ΙΔΙΟΚΤΗΤΗΣ" (owner) label, the title **Πυθέας ο Μεσσήνιος** in embossed gold Alegreya Black, a small diamond divider, the italic line "Ημερολόγιο ενός ταξιδιού γύρω από τον κόσμο, κρυμμένο μέσα σε μία πόλη." and "ΓΥΡΙΣΕ ΣΕΛΙΔΑ ΓΙΑ ΝΑ ΞΕΚΙΝΗΣΕΙΣ". |
| Map | `01-voyage-map.jpg` | Parchment page "Ο ΧΑΡΤΗΣ ΤΟΥ ΤΑΞΙΔΙΟΥ / Η πορεία". A snaking rust-red ink route links ten numbered stops (rust circles with cream numbers, italic country names), small wave scribbles in the margins, a compass star top right, and a dotted final leg to a red **X** labelled "Ο ΘΗΣΑΥΡΟΣ / ΚΑΛΑΜΑΤΑ". Unvisited stops are dashed empty circles with "?". |
| Entries 1–10 | `02-entry-01-china.jpg` … `11-entry-10-finland.jpg` | See *Entry page anatomy* below. |
| Sealed | `99-sealed-page-example.jpg` | A page not yet unlocked: lined parchment with a **torn, zig-zag right edge**, a large red wax seal with a padlock in the centre, "ΕΠΟΜΕΝΗ ΣΕΛΙΔΑ · No. 04", "Η σελίδα No. 04 είναι ακόμα σφραγισμένη" and instructions to find and scan the hidden QR. |
| Final | `12-final-page.jpg` | "ΤΕΛΟΣ ΤΟΥ ΗΜΕΡΟΛΟΓΙΟΥ" under a brass compass icon, the italic closing line "Όλα τα σημάδια αποκαλύφθηκαν. Ο θησαυρός περιμένει εκείνους που έμαθαν να κοιτούν την Καλαμάτα σαν εξερευνητές.", then "ΟΛΑ ΤΑ ΓΡΑΜΜΑΤΟΣΗΜΑ ΤΟΥ ΤΑΞΙΔΙΟΥ" with all ten stamps fanned in a slightly tilted row, signed "Π. Μ." |

### Entry page anatomy

1. **Paper**: warm parchment with faint horizontal ruled lines, a thin red margin line on the left, and 11 brass spiral rings down the spine with a soft spine shadow.
2. **Backdrop**: the country's landmark art (`05-assets/journal-uploads/NN-country-backdrop.jpg`, or `05-assets/lead-bg/`), heavily washed into the paper so it reads as a faded watercolour on the lower half.
3. **Eyebrow**: "ΚΑΤΑΧΩΡΗΣΗ No. 01" in small tracked caps.
4. **Title**: the country in Alegreya Black (for example **Κίνα**), with the subtitle beneath in rust italic ("Η αρχή του ταξιδιού").
5. **Stamp**: a real postage stamp (`05-assets/stamps/` or `journal-uploads/…-stamp`), tilted about 6°, with a deckled edge and a soft shadow, overlapped by a round grey **postmark** reading "ΚΑΛΑΜΑΤΑ 2026" with wavy cancellation lines.
6. **Body**: the riddle in Alegreya at about 17 px with generous line height, opening with a large rust **drop cap**.
7. **Signature**: a short rule then "Π. Μ." in italic.
8. **Compass watermark**: a brass compass rose in the lower left (`05-assets/compass/e-to-w.png` or `s-to-n.png`, per entry), plus a faint coffee-ring stain bottom right.
9. Page number "2 / 12" at the bottom centre.

---

## 2. Home page

**Code:** `03-source-code/app/page.tsx` and the section components it imports. **Screenshots:** `02-screenshots/home/home-01.jpg` … `home-12.jpg` (scrolling top to bottom), `mobile/home-mobile-hero.jpg`.

Sections in order:

1. **Hero** (`hero.tsx`) — full-bleed antique engraved map of Kalamata and its coast (`05-assets/map-wide.png`) darkened under the ink. Three chips: "30 ΙΟΥΛΙΟΥ 2026" · "ΔΩΡΕΑΝ ΣΥΜΜΕΤΟΧΗ" (brass outline) · "ΛΗΓΕΙ 21:00 ΤΟ ΣΑΒΒΑΤΟ". A three-line title — "Το Ταξίδι του" / **Πυθέα** (huge, brass) / "του Μεσσήνιου" — then an italic line, a solid brass ΜΠΕΣ ΣΤΟ ΚΥΝΗΓΙ button, a dark Η ΙΣΤΟΡΙΑ ΤΟΥ ΠΥΘΕΑ button, a compass rose in the bottom left, and "ΚΥΛΗΣΕ" with a chevron at the bottom.
2. **Journal teaser** (`journal-teaser.tsx`) — shows the real journal cover and explains that clues arrive in the journal.
3. **Register** (`register.tsx`) — sign up and join or create a team.
4. **Prize pool** (`prize-pool.tsx`) — the prize, with coins floating and bobbing.
5. **Journey** (`journey.tsx`) — "9 countries, 9 leads" path with locked and unlocked stops.
6. **Story** (`story.tsx`) — "Ι. Ο ΘΡΥΛΟΣ", the legend of Pytheas.
7. **Treasure** (`treasure.tsx`, `treasure-equation.tsx`) — what the treasure is.
8. **How it works** (`how-it-works.tsx`) — numbered steps.
9. **FAQ** (`faq.tsx`) — accordion.
10. **Party** (`party.tsx`) — the closing celebration.

All copy for these sections is in `03-source-code/lib/i18n.ts` (Greek and English dictionaries).

---

## 3. Game guide — `/guide`

**Code:** `app/guide/page.tsx` → `components/pythea/guide-view.tsx`, `guide-illustrations.tsx`. **Screenshots:** `02-screenshots/guide/`. A long-form "Ο ΠΛΗΡΗΣ ΟΔΗΓΟΣ" walkthrough with custom illustrations. The how-to-play clip is `05-assets/how-to-play/search-area.mp4`.

## 4. Final standings — `/standings`

**Code:** `app/standings/page.tsx` (its view component is admin-shared and left out); the same ranked-list look is in `components/pythea/leaderboard-view.tsx`. **Screenshots:** `02-screenshots/standings/` ("ΤΕΛΙΚΗ ΚΑΤΑΤΑΞΗ — Το ταξίδι του Πυθέα!", headline counts such as 40 teams and 127 explorers, then the ranked list with gold, silver and bronze podium colours). These contain real names.

## 5. Brand page — `/brand`

**Code:** `app/brand/page.tsx` → `components/brand/brand-playground.tsx`, `th-mark.tsx`. **Screenshots:** `02-screenshots/brand/`. Use with `01-brand-kit/`.

## 6. Winner and hunt-complete moments

Not screenshotted because they need a finished team, but fully in code: `components/pythea/winner-reveal.tsx`, `hunt-complete-banner.tsx`, `handwritten-note.tsx`, `note2-content.tsx`, `compass-pickup-popup.tsx`. Artwork: `05-assets/pythea/hunt-complete-celebration.png`, `05-assets/pythea/treasure-equation.png`.
