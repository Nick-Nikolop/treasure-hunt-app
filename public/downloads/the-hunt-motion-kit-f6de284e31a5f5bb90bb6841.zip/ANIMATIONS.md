# Animations — exact values and video recipes

The site uses **Framer Motion** for most motion and a few CSS keyframes (in `03-source-code/styles/globals.css`). Times are in seconds. Cubic-bezier easings are written as `[x1, y1, x2, y2]`.

House style: slow, weighty and paper-like. Nothing bounces except the winner badge. The most-used entrance easing is the soft "expo-out" curve **`[0.16, 1, 0.3, 1]`**.

---

## 1. Journal page turn (the signature move)

Source: `components/pythea/poreia-view.tsx`.

- The book sits in a 3D scene: `perspective: 2800px`, `perspective-origin: 50% 40%`.
- The turning leaf is hinged on the **spine (left edge)**: `transform-origin: left center`.
- It rotates on the Y axis from `0°` to `-180°` (forward) or from `-180°` to `0°` (back) over **1.5 s** with easing **`[0.36, 0.1, 0.2, 1]`**: a slow lift, a fast sweep through the middle, then a soft settle.
- The front of the leaf shows the current page; its back face shows the blank reverse of the paper (`backface-visibility: hidden`, the back is pre-rotated 180°).
- A **lift shadow** gradient (transparent → 55% black, toward the spine) fades `0 → 0.5 → 0.15` opacity over the same 1.5 s (keyframe times 0, 0.5, 1, ease-in-out), so the paper darkens as it stands upright and lightens as it lands.
- A permanent spine gutter shadow (black 35% → transparent, 40–56 px wide) sits over the left edge.
- The page underneath is already the destination page, so it is revealed as the leaf sweeps away.
- Page dots: the active dot widens into a brass pill (CSS transition on width and colour).
- **Light mode** (the toggle under the book) swaps the 3D flip for a flat horizontal slide: the two pages sit side by side and slide one page-width left (or right) in 0.45 s with easing `[0.4, 0, 0.2, 1]`.

**Video recipe:** 3D layer pivoting on its left edge, Y rotation 0 → −180° over 36 frames (24 fps), custom ease as above, shadow layer multiplied on top peaking at the midpoint. Hold each page for about 3–4 s so the text can be read.

## 2. Voyage map route drawing

Source: `poreia-view.tsx` (map page).

- Faint dashed full route (`stroke-dasharray: 5 7`, 22% opacity) is always visible as a guide.
- The inked rust route (`oklch(0.45 0.1 40)`, about `#8A3B1E`, 2.4 px, round caps) **draws on** from 0 to the last unlocked stop: path-length animation, **1.8 s, ease-in-out, 0.35 s delay**.
- Once all ten stops are found, the final leg to the treasure draws on: **0.9 s, ease-in-out, 2.1 s delay**, and the X turns solid red (`oklch(0.45 0.13 30)`) with "Ο ΘΗΣΑΥΡΟΣ / ΚΑΛΑΜΑΤΑ".
- Stops pop in one after another: **0.45 s each, starting 0.45 s, staggered 0.18 s, ease-out**, scaling from their own centre.

**Video recipe:** trim-path the route, then pop the numbered circles in sequence, then draw the last dotted leg and stamp the X. The treasure moment works best with a small ink-splash or stamp-down beat.

## 3. Journal cover idle motion

Source: `components/pythea/journal-cover.tsx` + `globals.css`.

- **Ribbon bookmark** — `ribbon-sway`: rotate −1° → 1.2° → −1° over **5.5 s**, ease-in-out, infinite, pivoting from the top.
- **Compass in the wax seal** — `compass-sway`: rotate −8° → 8° → −8° over **6 s**, ease-in-out, infinite, like a needle settling.

## 4. Home hero entrance

Source: `components/pythea/hero.tsx`.

- Chips row: fade + rise 20 px, **1 s, delay 0.1 s**.
- Title lines stagger in like type rising out of a slot: each line is masked and slides up from `y: 110%` to `0%` while fading in, **1 s duration, delay 0.3 s + 0.12 s × line index, easing `[0.16, 1, 0.3, 1]`**.
- Buttons and subtitle: fade + rise 20 px, **1 s, delay 1.1 s**.
- The map behind stays still; the dust motes drift (see 7).

## 5. Section reveals on scroll (home, guide)

Source: `journal-teaser.tsx`, `journey.tsx`, `story.tsx`, `treasure.tsx`, `prize-pool.tsx`, `how-it-works.tsx`.

- Headings: fade + rise **20 px over 0.8 s**, triggered once when the section enters view.
- Cards and illustrations: fade + rise **24–30 px over 0.8–0.9 s** with **`[0.16, 1, 0.3, 1]`**, sibling items delayed by **0.1–0.15 s**.

## 6. Floating objects

- **Prize-pool coins**: bob `y: 0 → −14 px → 0` and `rotate: 0 → 8° → 0`, duration **6 s + 1.5 s per coin** (so they never sync), ease-in-out, infinite.
- **`float-slow`** (CSS): `translateY(0) rotate(0)` → `translateY(−12px) rotate(2deg)` → back, **7 s**, ease-in-out, infinite.
- **Compass rose** (`compass-rose.tsx`): outer ring rotates 360° in **240 s**, inner ring −360° in **180 s**, linear, infinite. It should look almost static.

## 7. Atmosphere particles

Source: `components/pythea/particles.tsx`. Small warm dust motes drift upward and sideways across the whole screen on a **14 s** loop with random negative start offsets (up to −30 s) so the field is already populated at first frame. Very low opacity: felt more than seen.

## 8. Attention cues

- **`hold-breathe`**: a brass glow pulses around a waiting button — box-shadow 0 → 16 px / 3 px spread at 62% brass → 0.
- **`hold-nudge`**: a tiny shake that only happens in the last 20% of the loop (−2 px / −0.8° → 2 px / 0.8° → settling), so it reads as a tap on the shoulder, not a shiver.

## 9. Winner reveal

Source: `components/pythea/winner-reveal.tsx`. The text fades up 12 px over 0.5 s; the trophy/badge springs in from `scale 0, rotate −30°` to `scale 1, rotate 0` with a **spring (stiffness 140, damping 12), 0.1 s delay**. This is the only bouncy motion on the site; save it for the treasure-found climax.

---

## Suggested video structure (journal-led, about 45–60 s)

1. **Open on the desk** (0–3 s): ink background, dust motes, the closed cover with ribbon sway. Title "Πυθέας ο Μεσσήνιος" glints in gold.
2. **Cover turn** (3–5 s): the signature page turn reveals the voyage map.
3. **Route draws** (5–10 s): the ink route snakes through the ten stops; the X at Kalamata stays faint.
4. **Entry montage** (10–40 s): flip through entries; on each, the stamp drops in at its tilt, the postmark presses down, the drop cap and first lines write on. Use 2–3 s per entry or feature three entries in full.
5. **Sealed page beat** (40–44 s): a page with the wax seal and torn edge; the seal cracks open (scan the QR).
6. **Final page** (44–52 s): all ten stamps fan into a row; the closing line appears; the map's last leg draws to the X.
7. **End card** (52–60 s): "ΑΝΑΚΑΛΥΨΕ ΤΟ ΑΓΝΩΣΤΟ ΜΕΣΑ ΣΤΟ ΓΝΩΡΙΜΟ" + logo (`01-brand-kit/logo/`) + thehunt.gr.

Sound direction: paper rustle on each turn, a soft wax-press thud for stamps and seals, a quill scratch for writing on text, and a warm, adventurous string bed.
