# 02 — Logo

## THE logo

**`logo/the-hunt-master-logo-th-compass.png`** (1254 × 1254 px, transparent background)

The gold **TH** monogram inside a compass ring, with **N / E / S / W** in the four gaps of the ring.
This is the one and only master logo of The Hunt.

## Rules

- **One logo.** There is no second version, no wordmark variant, no icon-only variant.
- **Never recolour it.** The gold, with its texture, bevel and shading, is part of the logo. No white, black, single-colour or tinted versions.
- **Never redraw or distort it.** No stretching, rotating, outlines, extra glows or drop shadows.
- **Backgrounds.** It works best on the deep ink brown (`#130C06`) or on parchment (`#F5E6CA`).
  See `logo/preview-master-logo-on-ink.png` and `logo/preview-master-logo-on-parchment.png`.
  Avoid busy photos behind it; if a photo is needed, darken it heavily first.
- **Clear space.** Keep empty space around the logo of at least the height of the “N” letter on every side.
- **Minimum size.** 48 px on screen / 15 mm in print, so the compass letters stay readable.
- **Source file.** It is currently a PNG. For large print (banners, signage), ask for a high-resolution or vector version first.

## Gold of the logo (sampled from the master file)

The gold is a metallic ramp, not a single flat colour. Use these values when you need to pick a matching gold for
text or graphics next to the logo — never to repaint the logo itself.

| Role | HEX |
| --- | --- |
| Highlight | `#FFF2A7` |
| Light gold | `#FABC47` |
| Mid gold (main) | `#D58936` |
| Deep gold | `#AC6319` |
| Shadow | `#3F1904` |

## The first hunt's logo (for reference only)

**`logo/first-hunt-pytheas-compass-logo.png`** (2200 × 2200 px, transparent)

The flat gold compass with a south-pointing needle, a dashed winding trail and a red **X**.
This belonged to the first hunt, *The Journey of Pytheas the Messenian* (Kalamata). It is not the master logo of The Hunt.

| Role | HEX |
| --- | --- |
| Compass gold | `#DDB754` |
| X red | `#C9332D` |
