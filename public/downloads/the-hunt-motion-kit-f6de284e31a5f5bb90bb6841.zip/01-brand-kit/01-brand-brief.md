# 01 — Brand brief

## 1. What The Hunt is presented as

**A city discovery experience.**

The video and all brand material present The Hunt as a brand / platform first. Each individual hunt
(for example the first one in Kalamata, *The Journey of Pytheas the Messenian*) is an edition of The Hunt.

## 2. One-sentence definition

> The Hunt transforms real places into interactive adventures through clues, QR checkpoints, puzzles and storytelling.

## 3. Who it is for

**People who have no idea what The Hunt is.** A general brand introduction: no prior knowledge assumed,
no jargon, nothing that only past players would understand.

## 4. What people should think afterwards

> “Ohhh, The Hunt is like the classic treasure hunt game, but next level — easy to get into, and in my city.”

Three ideas carry that sentence, and every piece of material should land all three:

1. **Familiar** — it is the treasure hunt everyone already knows.
2. **Next level** — clues, puzzles, stories and technology make it bigger than the childhood game.
3. **Accessible and local** — anyone can join, anyone has a chance of winning, and it happens in your own city.

## 5. Core mechanics and features

These are genuinely part of The Hunt and may be shown:

| Feature | Notes |
| --- | --- |
| Mystery | The overall tone: the city is hiding something. |
| Clues | The main thread players follow. |
| Riddles | Short wordplay / logic challenges. |
| Puzzles | Bigger problems to solve, alone or together. |
| Online + real world | Some steps happen on the phone / site, others on location. |
| QR checkpoints | Physical points in the city that unlock the next step. |
| Real-world locations | Real streets, landmarks and places, not invented ones. |
| Storytelling | Each hunt has a story, either fantasy or drawn from real history (e.g. Pytheas). |
| Easy for anyone | No special skills or gear needed. |
| A chance of winning | Everyone who plays can win. |
| Community | Playing together, with friends, family or strangers. |
| Prizes | Real rewards for the winners. |

Do not advertise mechanics outside this list (for example chat, mini-games or leaderboards) until they are confirmed.
