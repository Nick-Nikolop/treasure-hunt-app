# The Hunt — Brand Kit

Everything needed to brief a designer, video editor or agency on The Hunt.
Open `brand-sheet.html` in any browser for the visual version (swatches + type specimen).

| File | What it answers |
| --- | --- |
| `01-brand-brief.md` | What The Hunt is, who it is for, what people should think, core mechanics (questions 1–5) |
| `02-logo.md` | Which logo is THE logo and how to use it (question 6) |
| `03-colours.md` | Every brand colour in HEX / RGB / OKLCH, with roles (question 7) |
| `04-typography.md` | Fonts, weights, sizes and where to get them (question 8) |
| `05-open-questions.md` | Questions 9–18 that are still to be decided |
| `tokens/colours.css` | Colours as CSS variables, ready to paste into a website |
| `tokens/colours.json` | Colours as JSON, for apps, Figma plugins or scripts |
| `logo/` | Logo files (master + the first hunt's logo) and previews on dark / light |
| `brand-sheet.html` | One-page visual brand sheet |

## The short version

- **What it is:** a city discovery experience.
- **One line:** The Hunt transforms real places into interactive adventures through clues, QR checkpoints, puzzles and storytelling.
- **After watching:** “Ohhh, The Hunt is like the classic treasure hunt game, but next level, easy to get into, and in my city.”
- **Logo:** the gold TH monogram inside the N / E / S / W compass ring. One logo, its gold is never recoloured.
- **Colours:** deep ink brown `#130C06`, brass gold `#E5AC4C`, parchment `#F5E6CA`, cream text `#EBDCC5`, teal accent `#35898A`.
- **Fonts:** Alegreya (headings, serif) + Alegreya Sans (body). Both free on Google Fonts, both support Greek.
