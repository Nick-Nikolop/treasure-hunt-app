# 05 — Still to decide

Questions 1–8 are answered in this kit. These are still open; fill them in when ready.

| # | Question | Answer |
| --- | --- | --- |
| 9 | Tagline / allowed phrases, and phrases to avoid | |
| 10 | Explain clearly from the start, or start mysterious and reveal halfway? | |
| 11 | Secret-society / mask look: core brand, one event only, or avoid? | |
| 12 | Real product assets (app screens, QR screen, map, photos / video from Kalamata) | |
| 13 | How much real footage vs motion design? | |
| 14 | Language (Greek / English / both) and voiceover or not | |
| 15 | Music personality | |
| 16 | Call to action and exact URL / handle (e.g. thehunt.gr) | |
| 17 | What must NOT appear visually (pirates, treasure chests, parchment maps, AI people…) | |
| 18 | 2–5 references you like (videos, brands, trailers) | |
