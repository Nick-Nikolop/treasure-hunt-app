# 04 — Typography

Two families from the same designer (Juan Pablo del Peral, Huerta Tipográfica), so they match by design.
Both are **free** (SIL Open Font License, fine for commercial use, print and video) and both fully support **Greek and Latin**.

| Role | Font | Style | Weights in use | Download |
| --- | --- | --- | --- | --- |
| Headings, titles, big numbers | **Alegreya** | Serif, calligraphic, literary | 400, 500, 700, 800, 900 + italics | https://fonts.google.com/specimen/Alegreya |
| Body text, buttons, labels | **Alegreya Sans** | Humanist sans-serif | 400, 500, 700, 800 | https://fonts.google.com/specimen/Alegreya+Sans |

Personality: **adventurous, mysterious, editorial** — like an old explorer's journal, but clean and readable on a phone.

## Hierarchy

| Element | Font | Weight | Size (desktop / mobile) | Line height | Notes |
| --- | --- | --- | --- | --- | --- |
| Display / hero title | Alegreya | 800–900 | 60 / 36 px | 1.1 | Short, punchy lines |
| Section title | Alegreya | 700 | 36 / 28 px | 1.2 | |
| Card / small title | Alegreya | 700 | 22 / 20 px | 1.3 | |
| Quotes, story lines | Alegreya | 400 italic | 20 / 18 px | 1.5 | For narrative and clue text |
| Body text | Alegreya Sans | 400 | 17 / 16 px | 1.6 | Keep lines to about 70 characters |
| Eyebrow / small label | Alegreya Sans | 700 | 12–13 px | 1.4 | UPPERCASE, letter-spacing 0.2em |
| Buttons | Alegreya Sans | 700 | 15–16 px | 1 | |
| Captions | Alegreya Sans | 400 | 14 px | 1.5 | Muted text colour |

## Rules

- Never use more than these two families.
- **Greek in UPPERCASE has no accents** (ΠΥΘΕΑΣ, not ΠΥΘΈΑΣ).
- Headings in brass gold or cream; body text in cream (dark) or ink (light).
- Body text never smaller than 14 px.

## For video / motion

- Titles: Alegreya 800–900, short lines, generous spacing.
- Kinetic / caption text: Alegreya Sans 700.
- Clue or riddle text on screen: Alegreya italic, so it feels written, like a note.
