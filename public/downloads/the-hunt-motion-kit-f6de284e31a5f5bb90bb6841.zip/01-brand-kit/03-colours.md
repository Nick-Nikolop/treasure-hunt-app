# 03 — Colours

The palette is **vintage cartography**: deep ink, aged paper, brass and a touch of sea teal.
These are the exact colours used on the live site of the first hunt (thehunt.gr). The site defines them in OKLCH;
HEX and RGB below are the exact conversions.

## Core palette

| Role | Name | HEX | RGB | OKLCH | Use it for |
| --- | --- | --- | --- | --- | --- |
| Primary | Brass gold | `#E5AC4C` | 229, 172, 76 | `oklch(0.78 0.13 78)` | Buttons, highlights, key words, links, focus rings |
| Background dark | Ink | `#130C06` | 19, 12, 6 | `oklch(0.16 0.018 62)` | Main background (the brand is dark by default) |
| Background light | Parchment | `#F5E6CA` | 245, 230, 202 | `oklch(0.93 0.04 82)` | Light sections, print, paper-like surfaces |
| Text | Cream | `#EBDCC5` | 235, 220, 197 | `oklch(0.9 0.035 78)` | Main text on dark backgrounds |
| Accent | Sea teal | `#35898A` | 53, 137, 138 | `oklch(0.58 0.08 196)` | Secondary highlights, maps, small details (use sparingly) |

## Supporting colours

| Role | HEX | RGB | OKLCH | Use it for |
| --- | --- | --- | --- | --- |
| Surface / cards | `#1D140D` | 29, 20, 13 | `oklch(0.2 0.02 60)` | Cards and panels on the ink background |
| Recessed surface | `#271D12` | 39, 29, 18 | `oklch(0.24 0.025 70)` | Inset areas, “sealed page” panels |
| Muted surface | `#2B221A` | 43, 34, 26 | `oklch(0.26 0.02 62)` | Quiet backgrounds, disabled areas |
| Border | `#41362A` | 65, 54, 42 | `oklch(0.34 0.025 66)` | Lines, dividers, card outlines |
| Muted text | `#AFA390` | 175, 163, 144 | `oklch(0.72 0.03 80)` | Captions, secondary text |
| Bright text | `#F9F1E3` | 249, 241, 227 | `oklch(0.96 0.02 80)` | Text on teal or on very dark areas |
| Deep teal | `#163335` | 22, 51, 53 | `oklch(0.3 0.035 200)` | Secondary panels and buttons |
| Text on gold | `#130C06` | 19, 12, 6 | `oklch(0.17 0.02 62)` | Text placed on brass gold buttons |
| Alert red | `#C5372F` | 197, 55, 47 | `oklch(0.55 0.18 28)` | Errors and warnings only |

## Prize / podium metals

| Place | HEX | OKLCH |
| --- | --- | --- |
| 1st — gold | `#E5AC4C` (brass) | `oklch(0.78 0.13 78)` |
| 2nd — silver | `#C3CBD4` | `oklch(0.84 0.015 250)` |
| 3rd — bronze | `#BF734B` | `oklch(0.63 0.11 48)` |

## How to combine them

- **Default look:** ink background, cream text, brass gold for what matters. Roughly 70% ink, 20% cream text, 8% gold, 2% teal.
- **Light look:** parchment background with ink text and gold accents.
- **Teal is a spice**, never a main colour. Never put teal and gold side by side as equal partners.
- **Good contrast pairs:** cream on ink, ink on parchment, ink on brass gold, brass gold on ink.
- **Avoid:** gold text on parchment for small text (too low contrast), pure white `#FFFFFF`, pure black `#000000`, purple.

## Ready-made files

- `tokens/colours.css` — CSS variables
- `tokens/colours.json` — JSON
