# The Hunt — Motion Kit

Everything needed to recreate the **thehunt.gr** pages (above all the travel **journal**) as motion-video scenes: the brand rules, real screenshots, the actual page code, the live text content, and every image, stamp, backdrop and font the pages use.

> **For the AI reading this:** Start with `PAGES.md` (what each screen looks like and contains), then `ANIMATIONS.md` (exact motion values), then `04-content/journal-entries.md` (the real journal text). Use the files in `05-assets/` directly in the video — they are the original artwork. Treat `03-source-code/` as the ground truth whenever a doc and the code disagree.

## Contents

| Folder | What it holds |
| --- | --- |
| `01-brand-kit/` | Brand brief, logo usage, colours, typography, colour tokens (CSS + JSON), logo files and a printable brand sheet. |
| `02-screenshots/` | Real renders of the site at 1440 px desktop and 390 px mobile: every journal page, the home page section by section, the game guide, final standings and the brand page. |
| `03-source-code/` | The page and component code (Next.js + React + Tailwind + Framer Motion) for the public pages, plus `styles/globals.css` with all theme tokens and CSS keyframes. Admin, database and API code is left out. |
| `04-content/` | The live journal content (10 entries, Greek + English) as Markdown and JSON, exported from the production lead table. |
| `05-assets/` | Stamps, page backdrops, compass watermarks, brand emblems and backdrops, the hero map, the logo, the how-to-play clip and the font files. |
| `PAGES.md` | Screen-by-screen anatomy: layout, components, copy and which screenshot and code file to look at. |
| `ANIMATIONS.md` | Every animation with its duration, easing, delay and trigger, plus recipes for re-creating them in video. |

## The look in one paragraph

A candle-lit explorer's desk. Near-black warm **ink** (`#130C06`) backgrounds, aged **parchment** pages (`#F5E6CA`) for anything "written by Pytheas", **brass** gold (`#E5AC4C`) for accents, rules and highlights, **cream** text (`#EBDCC5`) on dark, and a muted **teal** (`#35898A`) used sparingly. Headings use **Alegreya** (Black 900, often italic, with a soft vintage text-shadow); UI labels use **Alegreya Sans** in small, widely-tracked capitals. Ornaments are physical objects: wax seals, postage stamps, postmarks, brass spiral rings, a ribbon bookmark, compass roses and a hand-drawn voyage route.

## The story (for scriptwriting)

*Το Ταξίδι του Πυθέα του Μεσσήνιου* — "The Journey of Pytheas of Messene" — is a free, city-wide treasure hunt in **Kalamata** (30 July 2026). Players follow the travel journal of a fictional well-travelled explorer, Pytheas, who "visited" ten countries. Each journal entry is a riddle pointing to a real place in Kalamata linked to that country. Scanning a hidden QR code at each spot unseals the next page. After the 10th stop, the route leads to the treasure — marked with an X at Kalamata on the voyage map. Tagline: **ΑΝΑΚΑΛΥΨΕ ΤΟ ΑΓΝΩΣΤΟ ΜΕΣΑ ΣΤΟ ΓΝΩΡΙΜΟ** ("Discover the unknown within the familiar").

The ten stops in order: China, Serbia, France, England, Egypt, Switzerland (Helvetia), Spain, Thailand, Turkey, Finland. The full text is in `04-content/journal-entries.md`.

## Notes

- The language is **Greek first**. English translations are included for every journal entry; the rest of the site's English copy is in `03-source-code/lib/i18n.ts`.
- `02-screenshots/standings/` shows real team and player names from the finished hunt. Blur or replace them before using them in anything public.
- The fonts are open-source (SIL Open Font License, see `05-assets/fonts/OFL.txt`).
- The bottom-left "Issues" pill visible in some screenshots is a development overlay, not part of the design.
